<div align="center">

# 🌐 XHTTP Installer

### نصب خودکار پروکسی VLESS+XHTTP+TLS با Relay روی Vercel یا Netlify

[![Bash](https://img.shields.io/badge/Bash-Script-4EAA25?style=for-the-badge&logo=gnu-bash&logoColor=white)](#)
[![Ubuntu](https://img.shields.io/badge/Ubuntu-20.04%2B-E95420?style=for-the-badge&logo=ubuntu&logoColor=white)](#)
[![License](https://img.shields.io/badge/License-MIT-yellow?style=for-the-badge)](#)

[![Vercel](https://img.shields.io/badge/Vercel-Supported-000000?style=flat-square&logo=vercel)](#)
[![Netlify](https://img.shields.io/badge/Netlify-Supported-00C7B7?style=flat-square&logo=netlify)](#)
[![Xray](https://img.shields.io/badge/Xray--core-VLESS%2BXHTTP-purple?style=flat-square)](#)
[![SSL](https://img.shields.io/badge/SSL-Let's%20Encrypt-003A70?style=flat-square&logo=letsencrypt)](#)

</div>

---

## ⚡ نصب سریع با یک دستور

```bash
bash <(curl -fsSL https://raw.githubusercontent.com/avacocloud/XHTTP-Installer/main/install.sh)
```

---

## ✨ این پروژه چیه؟

یه اسکریپت **یک‌خطی** برای راه‌اندازی پروکسی **VLESS+XHTTP+TLS** با استفاده از **CDN رایگان Vercel یا Netlify** به‌عنوان relay.

به‌جای اینکه کلاینت مستقیم به سرور وصل بشه (که IP لو میره و فیلتر میشه)، ترافیک از Edge Function یه پلتفرم معروف عبور می‌کنه — پس IP سرورت مخفی میمونه.

### 🎯 مزایا

| ویژگی | توضیح |
|--------|--------|
| 🛡️ **مخفی‌سازی IP** | IP سرور پشت CDN معتبر مخفی میشه |
| 🌍 **سرعت بالا** | ترافیک از CDN جهانی Netlify/Vercel |
| 💰 **رایگان** | با plan رایگان Vercel یا Netlify |
| 🔐 **TLS معتبر** | گواهی Let's Encrypt خودکار |
| ⚡ **یک خط نصب** | بدون تجربه یا نیاز به تنظیمات دستی |
| 🔁 **AutoFix هوشمند** | اگه چیزی خراب شد، خودکار درست می‌کنه |

---

## 🔄 چطور کار می‌کنه؟

```
📱 Client  ──VLESS+XHTTP+TLS──▶  🌐 CDN (Vercel/Netlify)  ──HTTPS──▶  🔐 Xray Server  ──▶  🌍 Internet
```

CDN لایه‌ی عمومیه و Xray لایه‌ی مخفی. دنیای بیرون فقط دامنه‌ی CDN رو می‌بینه.

---

## 📋 پیش‌نیازها

- **سرور**: Ubuntu 20.04+ با دسترسی root
- **پورت‌ها**: 80 (SSL) و 443 (Xray)
- **دامنه**: ساب‌دامنه‌ای که A record اون به IP سرور اشاره کنه
- **توکن CDN**: Vercel یا Netlify

---

## 🚀 نصب در ۴ مرحله

**۱.** دستور بالا رو روی سرور اجرا کن

**۲.** پلتفرم رو انتخاب کن (Vercel یا Netlify)

**۳.** اطلاعات بخواسته‌شده رو وارد کن (دامنه، توکن، ...)

**۴.** کانفیگ `vless://...` رو در نهایت کپی کن و توی کلاینتت وارد کن

---

## 🐛 عیب‌یابی

- **HTTP 404 از relay** — طبیعیه! curl یه VLESS handshake نمی‌فرسته؛ کلاینت‌های واقعی درست کار می‌کنن.
- **Xray permission denied** — اسکریپت خودکار حل می‌کنه (systemd drop-in).
- **لاگ کامل**: `tail -f /tmp/xhttp-install.log`

---

## 📜 License

MIT
